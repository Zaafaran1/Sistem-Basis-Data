<?php
include '../config/koneksi.php';
$result = mysqli_query($koneksi, "SELECT * FROM pengiriman_sampah_ke_pengepul");
?>
<h2>Data Pengiriman Sampah</h2>
<a href="create.php">Tambah Pengiriman</a>
<table border="1">
    <tr><th>No</th><th>ID Transaksi</th><th>Kurir</th><th>Biaya</th><th>Aksi</th></tr>
    <?php $i=1; while($row = mysqli_fetch_assoc($result)) { ?>
    <tr>
        <td><?= $i++ ?></td>
        <td><?= $row['ID_Transaksi'] ?></td>
        <td><?= $row['Nama_Kurir'] ?></td>
        <td><?= $row['Biaya_Pengiriman'] ?></td>
        <td>
            <a href="update.php?id=<?= $row['ID_Pengiriman'] ?>">Edit</a> |
            <a href="delete.php?id=<?= $row['ID_Pengiriman'] ?>" onclick="return confirm('Yakin?')">Hapus</a>
        </td>
    </tr>
    <?php } ?>
</table>