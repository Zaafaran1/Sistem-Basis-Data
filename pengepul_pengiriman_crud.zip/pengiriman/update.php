<?php
include '../config/koneksi.php';
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM pengiriman_sampah_ke_pengepul WHERE ID_Pengiriman=$id"));
if ($_POST) {
    $q = "UPDATE pengiriman_sampah_ke_pengepul SET 
        ID_Pengepul='$_POST[pengepul]', ID_Transaksi='$_POST[transaksi]', 
        Tanggal_Kirim='$_POST[tanggal]', Total_Berat='$_POST[berat]', Status_Pengiriman='$_POST[status]',
        Nama_Kurir='$_POST[kurir]', No_Telepon_Kurir='$_POST[telp_kurir]', Biaya_Pengiriman='$_POST[biaya]' 
        WHERE ID_Pengiriman=$id";
    mysqli_query($koneksi, $q);
    header("Location: index.php");
}
?>
<form method="POST">
    <input name="pengepul" value="<?= $data['ID_Pengepul'] ?>">
    <input name="transaksi" value="<?= $data['ID_Transaksi'] ?>">
    <input type="date" name="tanggal" value="<?= $data['Tanggal_Kirim'] ?>">
    <input name="berat" value="<?= $data['Total_Berat'] ?>">
    <input name="status" value="<?= $data['Status_Pengiriman'] ?>">
    <input name="kurir" value="<?= $data['Nama_Kurir'] ?>">
    <input name="telp_kurir" value="<?= $data['No_Telepon_Kurir'] ?>">
    <input name="biaya" value="<?= $data['Biaya_Pengiriman'] ?>">
    <input type="submit" value="Update">
</form>