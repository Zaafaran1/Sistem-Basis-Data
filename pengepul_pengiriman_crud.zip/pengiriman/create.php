<?php
include '../config/koneksi.php';
if ($_POST) {
    $q = "INSERT INTO pengiriman_sampah_ke_pengepul (ID_Pengepul, ID_Transaksi, Tanggal_Kirim, Total_Berat, Status_Pengiriman, Nama_Kurir, No_Telepon_Kurir, Biaya_Pengiriman)
    VALUES ('$_POST[pengepul]', '$_POST[transaksi]', '$_POST[tanggal]', '$_POST[berat]', '$_POST[status]', '$_POST[kurir]', '$_POST[telp_kurir]', '$_POST[biaya]')";
    mysqli_query($koneksi, $q);
    header("Location: index.php");
}
?>
<form method="POST">
    <input name="pengepul" placeholder="ID Pengepul">
    <input name="transaksi" placeholder="ID Transaksi">
    <input type="date" name="tanggal">
    <input name="berat" placeholder="Total Berat (kg)">
    <input name="status" placeholder="Status Pengiriman">
    <input name="kurir" placeholder="Nama Kurir">
    <input name="telp_kurir" placeholder="Telepon Kurir">
    <input name="biaya" placeholder="Biaya">
    <input type="submit" value="Simpan">
</form>