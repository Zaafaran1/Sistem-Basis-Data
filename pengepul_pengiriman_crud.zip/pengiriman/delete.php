<?php
include '../config/koneksi.php';
$id = $_GET['id'];
mysqli_query($koneksi, "DELETE FROM pengiriman_sampah_ke_pengepul WHERE ID_Pengiriman=$id");
header("Location: index.php");
?>