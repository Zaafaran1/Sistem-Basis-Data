<?php
include '../config/koneksi.php';
$id = $_GET['id'];
mysqli_query($koneksi, "DELETE FROM pengepul WHERE ID_Pengepul = $id");
header("Location: index.php");
?>