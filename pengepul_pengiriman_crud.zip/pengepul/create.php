<?php
include '../config/koneksi.php';
if ($_POST) {
    $q = "INSERT INTO pengepul (Nama_Pengepul, No_Telepon, Email, Lokasi_Pengepul, Jenis_Sampah_Diterima, Kapasitas, Jadwal_Pengambilan, Status_Kerjasama)
          VALUES ('$_POST[nama]', '$_POST[telp]', '$_POST[email]', '$_POST[lokasi]', '$_POST[jenis]', '$_POST[kapasitas]', '$_POST[jadwal]', '$_POST[status]')";
    mysqli_query($koneksi, $q);
    header("Location: index.php");
}
?>
<form method="POST">
    <input name="nama" placeholder="Nama Pengepul" required>
    <input name="telp" placeholder="No Telepon" required>
    <input name="email" placeholder="Email" type="email" required>
    <textarea name="lokasi" placeholder="Lokasi Pengepul"></textarea>
    <textarea name="jenis" placeholder="Jenis Sampah Diterima"></textarea>
    <input name="kapasitas" type="number" placeholder="Kapasitas (kg)">
    <input name="jadwal" placeholder="Jadwal Pengambilan">
    <select name="status">
        <option>Aktif</option><option>Tidak Aktif</option>
    </select>
    <input type="submit" value="Simpan">
</form>