<?php
include '../config/koneksi.php';
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM pengepul WHERE ID_Pengepul = $id"));

if ($_POST) {
    $q = "UPDATE pengepul SET 
        Nama_Pengepul='$_POST[nama]', No_Telepon='$_POST[telp]', Email='$_POST[email]', 
        Lokasi_Pengepul='$_POST[lokasi]', Jenis_Sampah_Diterima='$_POST[jenis]', 
        Kapasitas='$_POST[kapasitas]', Jadwal_Pengambilan='$_POST[jadwal]', Status_Kerjasama='$_POST[status]' 
        WHERE ID_Pengepul=$id";
    mysqli_query($koneksi, $q);
    header("Location: index.php");
}
?>
<form method="POST">
    <input name="nama" value="<?= $data['Nama_Pengepul'] ?>">
    <input name="telp" value="<?= $data['No_Telepon'] ?>">
    <input name="email" value="<?= $data['Email'] ?>">
    <textarea name="lokasi"><?= $data['Lokasi_Pengepul'] ?></textarea>
    <textarea name="jenis"><?= $data['Jenis_Sampah_Diterima'] ?></textarea>
    <input name="kapasitas" value="<?= $data['Kapasitas'] ?>">
    <input name="jadwal" value="<?= $data['Jadwal_Pengambilan'] ?>">
    <select name="status">
        <option <?= $data['Status_Kerjasama'] == "Aktif" ? "selected" : "" ?>>Aktif</option>
        <option <?= $data['Status_Kerjasama'] == "Tidak Aktif" ? "selected" : "" ?>>Tidak Aktif</option>
    </select>
    <input type="submit" value="Update">
</form>