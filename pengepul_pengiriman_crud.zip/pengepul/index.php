<?php
include '../config/koneksi.php';
$result = mysqli_query($koneksi, "SELECT * FROM pengepul");
?>
<h2>Data Pengepul</h2>
<a href="create.php">Tambah Pengepul</a>
<table border="1">
    <tr>
        <th>No</th><th>Nama</th><th>Telepon</th><th>Email</th><th>Aksi</th>
    </tr>
    <?php $i = 1; while($row = mysqli_fetch_assoc($result)) { ?>
    <tr>
        <td><?= $i++ ?></td>
        <td><?= $row['Nama_Pengepul'] ?></td>
        <td><?= $row['No_Telepon'] ?></td>
        <td><?= $row['Email'] ?></td>
        <td>
            <a href="update.php?id=<?= $row['ID_Pengepul'] ?>">Edit</a> |
            <a href="delete.php?id=<?= $row['ID_Pengepul'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
        </td>
    </tr>
    <?php } ?>
</table>